//
//  AppDelegate.swift
//  DreamZzz
//
//  Created by Claudio Sennhauser on 11/27/17.
//  Copyright © 2017 Claudio Sennhauser. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        return true
}
    
}
